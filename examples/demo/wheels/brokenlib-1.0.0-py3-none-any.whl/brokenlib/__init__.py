"""brokenlib 1.0.0: string helpers for the demo app."""

__version__ = "1.0.0"


def greet(name: str) -> str:
    return f"hello, {name}"
