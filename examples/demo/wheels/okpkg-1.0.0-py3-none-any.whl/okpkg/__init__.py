"""okpkg 1.0.0: arithmetic helpers for the demo app."""

__version__ = "1.0.0"


def add(a: int, b: int) -> int:
    return a + b
