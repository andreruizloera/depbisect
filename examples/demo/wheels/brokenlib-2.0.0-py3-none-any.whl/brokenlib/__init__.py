"""brokenlib 2.0.0: string helpers for the demo app."""

__version__ = "2.0.0"


def greet(name: str) -> str:
    return f"Greetings, esteemed {name}!"
