"""okpkg 1.1.0: arithmetic helpers for the demo app."""

__version__ = "1.1.0"


def add(a: int, b: int) -> int:
    return a + b


def mul(a: int, b: int) -> int:
    return a * b
