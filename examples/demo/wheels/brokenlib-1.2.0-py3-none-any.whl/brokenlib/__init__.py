"""brokenlib 1.2.0: string helpers for the demo app."""

__version__ = "1.2.0"


def greet(name: str) -> str:
    return f"hello, {name}"
