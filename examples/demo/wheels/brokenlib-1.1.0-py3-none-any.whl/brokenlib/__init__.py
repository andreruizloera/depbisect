"""brokenlib 1.1.0: string helpers for the demo app."""

__version__ = "1.1.0"


def greet(name: str) -> str:
    return f"hello, {name}"
